# Giọng Kachi bé — ghi công, giấy phép, đồng thuận

Gói này là **audio đã tổng hợp**. Không có một mẫu thu gốc nào trong đây, và cũng không có trọng số mô hình.

## Mô hình đã dùng để sinh gói

| | |
|---|---|
| Bộ tổng hợp | **F5-TTS** — `SWivid/F5-TTS` (MIT) |
| Trọng số tiếng Việt | **`toandev/F5-TTS-Vietnamese`** — fine-tune `F5TTS_Base` trên `capleaf/viVoice` |
| Giấy phép trọng số | **CC-BY-NC-4.0** — ghi công · **phi thương mại** · không có điều khoản chia-sẻ-tương-tự |
| Bộ dữ liệu huấn luyện | **`capleaf/viVoice`** |
| Bộ mã hoá âm | Vocos (mel 24 kHz) |
| Ngày sinh gói | 2026-09-17 |

Điều kiện **NC** (phi thương mại) là điều kiện dự án này đã tự khẳng định một lần cho mô hình nghe
(`voice/README.md`): Kachi là một dự án **phi lợi nhuận**, phát hành công khai, không bán. Vì giấy phép
**không** có điều khoản chia-sẻ-tương-tự, gói audio sinh ra **không** bị buộc mang lại đúng giấy phép ấy —
nhưng nghĩa vụ **ghi công** thì vẫn còn, và nó nằm ở đây, ở `manifest.json`, và ở màn CREDITS trong app
(cả ba đọc **cùng một** trường dữ liệu — R7 của spec).

## Đồng thuận

Đây là **giọng một đứa trẻ, đã được nhân bản từ một bản thu có sự đồng ý**. Chủ dự án (`dangkhoi`) là
**cha của bé** và đã quyết định ngày **2026-09-16** cho phát hành gói này công khai qua kênh OTA của dự án
(*"giọng bé được nhiều người nghe cũng vui… take it easy thôi"* — ghi ở `docs/specs/kachi-voice-clone.html`
§4.8). Ba điều đi kèm quyết định đó, ghi thẳng ra đây để sau này không ai phải đoán:

- **Bản thu gốc không bao giờ vào kho mã.** `voice/record/` nằm trong `.gitignore`; bản thu và mọi bản cắt
  ở lại máy của chủ dự án. Thứ được phát hành là audio đã tổng hợp.
- **Tên gói không mang tên thật của bé** — *"Giọng Kachi bé"* (`kachi-giong-be-v1`).
- **Có đường rút, nhưng không thu hồi được bản đã tải.** Gỡ gói khỏi kho là nó biến mất khỏi mọi bản cài
  sau; bản đã tải về máy người khác thì không. Sự thật này thuộc về quyết định ở trên, không phải thứ
  thiết kế chữa được.

## Không dùng lại giọng này cho mục đích khác

Gói phát hành để Kachi **đọc câu trả lời của chính nó**. Dùng audio ở đây để dựng một giọng nhân bản khác,
để tạo phát ngôn mà người thật chưa từng nói, hoặc cho bất kỳ mục đích thương mại nào — đều **ngoài** phạm
vi đồng thuận đã có, và ngoài điều kiện NC của mô hình.
